export function branchingModel(depth){
 if(!Number.isInteger(depth)||depth<1||depth>6)throw Error('BRANCH_DEPTH: use integer depth 1–6');
 const nodes=[{id:0,parent:null,level:0,start:[0,0],end:[0,-1/(depth+1)]}],levels=[[0]];
 for(let level=1;level<=depth;level++){
  const row=[];
  for(const parentId of levels[level-1])for(const sign of [-1,1]){
   const parent=nodes[parentId],id=nodes.length;
   nodes.push({id,parent:parentId,level,start:[...parent.end],end:[parent.end[0]+sign*.36/2**(level-1),-(level+1)/(depth+1)]});row.push(id);
  }levels.push(row);
 }
 return{depth,nodes,levels,terminal_counts:levels.map(row=>row.length),total_counts:levels.map((_,i)=>nodes.filter(n=>n.level<=i).length),assumption:'Each terminal segment produces exactly two child segments; no assertion about natural tree growth.'};
}
export function branchingState(depth,level,time){
 const data=branchingModel(depth);
 if(!Number.isInteger(level)||level< -1||level>depth+1)throw Error('BRANCH_LEVEL: outside the computed depth');
 const target=Math.min(depth,Math.max(0,level)),q=Math.max(0,Math.min(1,(time-.15)/1.25)),growth=level<0||level>depth||target===0?1:1-(1-q)**3,shown=target>0&&growth<=0?target-1:target;
 return{target,growth,shown,terminal_count:data.terminal_counts[shown],total_count:data.total_counts[shown]};
}
