import {branchingModel,branchingState} from './branching-model.js';
const memo=new Map();
const rand=(i,seed)=>{let x=(i+1)^seed;x=Math.imul(x^(x>>>16),0x45d9f3b);x=Math.imul(x^(x>>>16),0x45d9f3b);return((x^(x>>>16))>>>0)/4294967296};
export function inkBranch(c,s,w,h,t,u,p,seed){
 const {depth,level}=s.parameters.branching,key=String(depth);if(!memo.has(key))memo.set(key,branchingModel(depth));const data=memo.get(key),{target,growth,shown}=branchingState(depth,level,t),opening=level<0,unit=Math.min(w,h),cx=w*.5,base=h*.73,sx=w*.53,sy=h*.32;
 c.save();
 // Original fine paper fibers and an ink wash; no raster/source image asset.
 for(let i=0;i<1100;i++){const x=rand(i*5,seed)*w,y=rand(i*5+1,seed)*h;c.strokeStyle=`rgba(108,91,59,${.018+rand(i*5+2,seed)*.035})`;c.lineWidth=.4*w/720;c.beginPath();c.moveTo(x,y);c.lineTo(x+(rand(i*5+3,seed)-.5)*unit*.013,y+unit*.002);c.stroke();}
 const wash=c.createRadialGradient(cx,h*.64,0,cx,h*.64,w*.42);wash.addColorStop(0,'#52746d12');wash.addColorStop(1,'#52746d00');c.fillStyle=wash;c.fillRect(0,h*.38,w,h*.4);
 c.textAlign='center';c.textBaseline='middle';c.fillStyle=p.text;c.font=`400 ${unit*.036}px VibeSerif,serif`;c.fillText(opening?'如果每条末梢都一分为二':`第${shown}层 · 末层段数`,cx,h*.275);
 c.font=`500 ${unit*.12}px VibeSerif,serif`;c.fillText(String(data.terminal_counts[shown]),cx,h*.335);
 // A topic seal is ordinary mathematical chapter text, never a production label.
 const stampX=w*.135,stampY=h*.305,stampW=unit*.065,stampH=unit*.12;c.strokeStyle=p.danger;c.lineWidth=unit*.002;c.strokeRect(stampX-stampW/2,stampY-stampH/2,stampW,stampH);c.fillStyle=p.danger;c.font=`400 ${unit*.043}px VibeBrush,VibeSerif,serif`;c.fillText('二',stampX,stampY-unit*.026);c.fillText('分',stampX,stampY+unit*.026);
 for(const node of data.nodes){if(node.level>target)continue;const g=node.level===target?growth:1;if(g<=0)continue;
  const [a,b]=node.start,[x,y]=node.end,x0=cx+a*sx,y0=base+b*sy,x1=cx+x*sx,y1=base+y*sy,xx=x0+(x1-x0)*g,yy=y0+(y1-y0)*g;
  const bend=(rand(node.id*7,seed)-.5)*unit*.017;c.lineCap='round';
  for(let k=0;k<3;k++){c.strokeStyle=k===0?'#243c35b8':k===1?'#314d4266':'#63756b28';c.lineWidth=Math.max(.65,unit*.009*(1-node.level/(depth+1)))*(1-k*.27);c.beginPath();c.moveTo(x0+k*.3,y0);c.bezierCurveTo(x0+(xx-x0)*.18+bend,y0+(yy-y0)*.4,x0+(xx-x0)*.72, y0+(yy-y0)*.88,xx,yy);c.stroke();}
  if(node.level===shown){c.fillStyle='#496a57';c.beginPath();c.ellipse(xx,yy,unit*.005,unit*.011,(node.end[0]-node.start[0])>0?.5:-.5,0,Math.PI*2);c.fill();}
 }
 c.fillStyle=p.text;c.font=`400 ${unit*.035}px VibeSerif,serif`;c.fillText(`连同前面：${data.total_counts[shown]}段`,cx,h*.775);
 c.restore();
}
