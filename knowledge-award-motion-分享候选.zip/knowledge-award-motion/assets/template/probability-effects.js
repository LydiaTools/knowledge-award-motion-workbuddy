const clamp=x=>Math.max(0,Math.min(1,x));
const memo=new Map();
function random(i,seed){let x=(i+1)^seed;x=Math.imul(x^(x>>>16),0x45d9f3b);x=Math.imul(x^(x>>>16),0x45d9f3b);return((x^(x>>>16))>>>0)/4294967296;}
export const chance=(p,n)=>1-Math.pow(1-p,n);
export function percentage(value){const n=value*100;if(n!==0&&Math.abs(n)<.01)return n.toExponential(2)+'%';return Number(n.toFixed(4)).toString()+'%';}
export function trialData(count,trials,p,seed){
  const key=[count,trials,p,seed].join(':');if(memo.has(key))return memo.get(key);
  const first=Array.from({length:count},(_,i)=>{for(let n=1;n<=trials;n++)if(random(i*256+n,seed)<p)return n;return null});
  const counts=Array.from({length:trials+1},(_,n)=>first.filter(v=>v!==null&&v<=n).length);
  const result={count,trials,probability:p,seed,first_success:first,counts,theoretical:counts.map((_,n)=>chance(p,n))};memo.set(key,result);return result;
}
const stage=(s,u)=>Math.floor(clamp((u-.08)/.75)*(s.parameters?.trials??20));
function point(c,x,y,r,color){const g=c.createRadialGradient(x,y,0,x,y,r*6);g.addColorStop(0,color);g.addColorStop(1,'#00000000');c.fillStyle=g;c.fillRect(x-r*6,y-r*6,r*12,r*12);c.fillStyle=color;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}
export function probabilityChart(c,s,w,h,t,u,p){
  const trials=s.parameters?.trials??20,q=s.parameters?.probability??.01,n=stage(s,u),a=chance(q,n),maxY=Math.max(.1,Math.min(1,chance(q,trials)*1.22)),x0=w*.15,x1=w*.85,y0=h*.70,y1=h*.43,portrait=h>w,unit=Math.min(w,h);
  c.save();c.textAlign='center';c.fillStyle=p.accent;c.font=`500 ${unit*(portrait?.16:.125)}px VibeSerif,serif`;c.fillText((a*100).toFixed(1)+'%',w*.5,h*.39);
  c.font=`400 ${unit*.039}px VibeSerif,serif`;c.fillStyle=p.text;c.fillText(`至少成功一次 · 已尝试 ${n} 次`,w*.5,h*.445);
  c.lineWidth=Math.max(1,w/1080);c.strokeStyle=p.text+'55';c.beginPath();c.moveTo(x0,y1+h*.045);c.lineTo(x0,y0);c.lineTo(x1,y0);c.stroke();
  for(let k=0;k<=4;k++){const yy=y0-(y0-y1)*k/4;c.beginPath();c.moveTo(x0,yy);c.lineTo(x1,yy);c.strokeStyle=p.text+'14';c.stroke();c.textAlign='right';c.fillStyle=p.text+'99';c.font=`400 ${unit*.034}px VibeSerif,serif`;c.fillText(Math.round(maxY*k/4*100)+'%',x0-w*.015,yy+unit*.008);}
  c.beginPath();for(let k=0;k<=160;k++){const nn=k/160*n,x=x0+nn/trials*(x1-x0),y=y0-chance(q,nn)/maxY*(y0-y1);k?c.lineTo(x,y):c.moveTo(x,y);}c.strokeStyle=p.accent;c.lineWidth=unit*.0025;c.stroke();
  point(c,x0+n/trials*(x1-x0),y0-a/maxY*(y0-y1),unit*.004,p.accent);
  c.textAlign='center';c.font=`400 ${unit*.039}px VibeSerif,serif`;c.fillStyle=p.text+'aa';c.fillText('0',x0,y0+unit*.036);c.fillText(String(trials)+' 次',x1,y0+unit*.036);c.fillText(`1 − (1 − ${percentage(q)})ⁿ`,w*.5,h*.78);c.restore();
}
export function independentTrials(c,s,w,h,t,u,p,seed){
  const count=s.parameters?.count??1000,trials=s.parameters?.trials??20,q=s.parameters?.probability??.01,data=trialData(count,trials,q,seed),n=stage(s,u),cols=Math.ceil(Math.sqrt(count*(h>w?.76:2.9))),rows=Math.ceil(count/cols),span=w*.76,dx=span/cols,dy=Math.min(dx,h*.31/rows),x0=(w-cols*dx)/2,y0=h*.52-rows*dy/2;
  c.save();c.textAlign='center';c.font=`400 ${Math.min(w,h)*.038}px VibeSerif,serif`;c.fillStyle=p.text;c.fillText('至少成功过一次的组数 / 总组数',w*.5,h*.27);c.font=`500 ${Math.min(w,h)*.078}px VibeSerif,serif`;c.fillStyle=p.accent;c.fillText(`${data.counts[n]} / ${count}`,w*.5,h*.355);
  for(let i=0;i<count;i++){const yes=data.first_success[i]!==null&&data.first_success[i]<=n,just=yes&&data.first_success[i]===n;c.fillStyle=yes?p.accent:p.text+'30';c.beginPath();const x=x0+(i%cols+.5)*dx,y=y0+(Math.floor(i/cols)+.5)*dy;c.arc(x,y,Math.max(.8,Math.min(dx,dy)*(yes?.24:.14)),0,Math.PI*2);c.fill();if(just&&i%3===0)point(c,x,y,Math.min(dx,dy)*.2,p.accent);}
  c.fillStyle=p.text;c.font=`400 ${Math.min(w,h)*.034}px VibeSerif,serif`;c.fillText(`第 ${n} 次`,w*.5,h*.72);c.restore();
}
export function failureChain(c,s,w,h,t,u,p){
  const trials=s.parameters?.trials??20,q=s.parameters?.probability??.01,n=stage(s,u),cols=h>w?5:10,rows=Math.ceil(trials/cols),shown=Math.min(trials,50),cw=w*.78/cols,ch=Math.min(h*.26/Math.ceil(shown/cols),h*.055),x0=w*.11,y0=h*.36,unit=Math.min(w,h),failure=Math.pow(1-q,n);
  c.save();c.textAlign='center';c.textBaseline='middle';
  for(let i=0;i<shown;i++){const x=x0+(i%cols+.5)*cw,y=y0+(Math.floor(i/cols)+.5)*ch,active=i<n;c.fillStyle=active?p.accent+'20':p.text+'08';c.fillRect(x-cw*.43,y-ch*.42,cw*.86,ch*.84);c.strokeStyle=active?p.accent+'88':p.text+'20';c.lineWidth=w/1080;c.strokeRect(x-cw*.43,y-ch*.42,cw*.86,ch*.84);c.fillStyle=active?p.accent:p.text+'33';c.font=`400 ${Math.min(cw*.25,ch*.34)}px VibeSerif,serif`;c.fillText(percentage(1-q),x,y);}
  c.font=`400 ${unit*.035}px VibeSerif,serif`;c.fillStyle=p.text;if(trials>shown)c.fillText(`另有 ${trials-shown} 项同样相乘`,w*.5,h*.63);c.fillText(`全部失败：(1 − ${percentage(q)}) ^ ${n}`,w*.5,h*.67);c.fillStyle=p.danger;c.font=`500 ${unit*.09}px VibeSerif,serif`;c.fillText((failure*100).toFixed(1)+'%',w*.5,h*.735);c.restore();
}
