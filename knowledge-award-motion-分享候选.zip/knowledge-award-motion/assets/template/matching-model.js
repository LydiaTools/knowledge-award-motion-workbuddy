// Strict, complete one-to-one preferences. No randomness or inferred human outcomes.
export const leftLabel=i=>'ABCD'[i];
export const rightLabel=i=>'WXYZ'[i];
export const defaultMatching={left:[[0,1,2,3],[0,2,1,3],[1,0,3,2],[1,2,3,0]],right:[[1,0,3,2],[0,2,1,3],[2,3,1,0],[3,2,0,1]]};
export function validateMatching(model){
 const n=model?.left?.length;
 if(!Number.isInteger(n)||n<2||n>4||model.right?.length!==n)throw Error('MATCHING_SIZE: both sides need 2–4 preference rows');
 for(const side of ['left','right'])for(const row of model[side])if(!Array.isArray(row)||row.length!==n||new Set(row).size!==n||row.some(v=>!Number.isInteger(v)||v<0||v>=n))throw Error('MATCHING_PREFERENCE: every row must rank each opposite-side index exactly once');
 return n;
}
export function blockingPairs(model,pairs){
 const n=validateMatching(model),left=Array(n).fill(null),right=Array(n).fill(null);
 for(const [a,b]of pairs){if(left[a]!==null||right[b]!==null)throw Error('MATCHING_PAIRS: a participant is assigned twice');left[a]=b;right[b]=a;}
 const found=[];
 for(let a=0;a<n;a++)for(let b=0;b<n;b++)if(left[a]!==b&&(left[a]===null||model.left[a].indexOf(b)<model.left[a].indexOf(left[a]))&&(right[b]===null||model.right[b].indexOf(a)<model.right[b].indexOf(right[b])))found.push([a,b]);
 return found;
}
export function deferredAcceptance(model){
 const n=validateMatching(model),queue=Array.from({length:n},(_,i)=>i),next=Array(n).fill(0),held=Array(n).fill(null),events=[];
 const pairs=()=>held.flatMap((a,b)=>a===null?[]:[[a,b]]);
 while(queue.length){
  const a=queue.shift(),b=model.left[a][next[a]++],old=held[b],before=pairs();
  if(b===undefined)throw Error('MATCHING_EXHAUSTED: complete equal-size inputs should not exhaust choices');
  let outcome;
  if(old===null){held[b]=a;outcome='hold';}
  else if(model.right[b].indexOf(a)<model.right[b].indexOf(old)){held[b]=a;queue.push(old);outcome='replace';}
  else{queue.push(a);outcome='reject';}
  events.push({number:events.length+1,left:a,right:b,previous:old,outcome,before,after:pairs(),proposal_rank:next[a],receiver_rank_new:model.right[b].indexOf(a)+1,receiver_rank_old:old===null?null:model.right[b].indexOf(old)+1});
  if(events.length>n*n)throw Error('MATCHING_BOUND: repeated proposal');
 }
 const final=pairs(),blocking=blockingPairs(model,final);
 if(final.length!==n||blocking.length)throw Error('MATCHING_RESULT: incomplete or unstable output');
 return {n,events,final,blocking_pairs:blocking,conditions:['equal-size sides','strict complete preference lists','one-to-one allocation','left side proposes']};
}
