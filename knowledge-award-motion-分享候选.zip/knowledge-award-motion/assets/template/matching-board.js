import {deferredAcceptance,leftLabel,rightLabel} from './matching-model.js';
const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>1-(1-clamp(x))**3;
const leftColors=['#76c9ba','#91b5eb','#c4a3e4','#b3bfd2'],rightColors=['#e3b6ce','#e1bf7d','#cba28e','#87c6cd'];
const memo=new Map();
function result(model){const key=JSON.stringify(model);if(!memo.has(key))memo.set(key,deferredAcceptance(model));return memo.get(key)}
function line(c,x0,y0,x1,y1,color,width,progress=1,alpha=1){
 c.save();c.strokeStyle=color;c.lineWidth=width;c.globalAlpha*=alpha;c.beginPath();
 for(let i=0;i<=60;i++){const t=i/60*progress,xx=x0+(x1-x0)*t,yy=y0+(y1-y0)*(3*t*t-2*t*t*t)+Math.sin(Math.PI*t)*Math.abs(y1-y0)*.13;i?c.lineTo(xx,yy):c.moveTo(xx,yy)}c.stroke();
 if(progress>0&&progress<1){const t=progress,x=x0+(x1-x0)*t,y=y0+(y1-y0)*(3*t*t-2*t*t*t)+Math.sin(Math.PI*t)*Math.abs(y1-y0)*.13;c.shadowColor=color;c.shadowBlur=width*7;c.fillStyle=color;c.beginPath();c.arc(x,y,width*2,0,Math.PI*2);c.fill();}c.restore();
}
function avatar(c,x,y,r,color,id){
 c.save();c.translate(x,y);c.fillStyle=color;c.globalAlpha=.9;c.beginPath();c.moveTo(-r*.83,r*.9);c.quadraticCurveTo(-r*.7,r*.05,0,r*.05);c.quadraticCurveTo(r*.7,r*.05,r*.83,r*.9);c.closePath();c.fill();
 c.fillStyle='#f1dbc6';c.beginPath();c.ellipse(0,-r*.39,r*.5,r*.61,0,0,Math.PI*2);c.fill();
 c.fillStyle='#253144';c.beginPath();c.arc(0,-r*.58,r*.55,Math.PI,Math.PI*2);c.lineTo(r*.45,-r*.4);c.quadraticCurveTo(0,-r*.8,-r*.5,-r*.31);c.closePath();c.fill();
 c.fillStyle='#213145';for(const xx of [-.17,.17]){c.beginPath();c.arc(xx*r,-r*.39,r*.045,0,Math.PI*2);c.fill();}c.strokeStyle='#9b625e';c.lineWidth=r*.035;c.beginPath();c.arc(0,-r*.27,r*.14,.1,Math.PI-.1);c.stroke();
 c.font=`600 ${r*.65}px VibeSerif,serif`;c.textAlign='center';c.fillStyle='#0c1a2a';c.fillText(id,0,r*.6);c.restore();
}
export function matchingBoard(c,s,w,h,t,u,p){
 const m=s.parameters.matching,model={left:m.left,right:m.right},data=result(model),step=m.step,n=data.n,unit=Math.min(w,h),portrait=h>w;
 const xl=w*(portrait?.2:.26),xr=w*(portrait?.8:.74),top=h*.365,span=h*.30,ys=Array.from({length:n},(_,i)=>top+i*span/Math.max(1,n-1)),r=unit*(portrait?.043:.034),final=step>data.events.length,event=step>0&&!final?data.events[step-1]:null,q=ease((u-.04)/.61),decided=q>=.94;
 c.save();
 // Original night-space treatment: fixed moon, low ground, soft vertical shafts.
 const sky=c.createLinearGradient(0,h*.22,0,h*.79);sky.addColorStop(0,'#14244110');sky.addColorStop(.55,'#28406436');sky.addColorStop(1,'#172a4300');c.fillStyle=sky;c.fillRect(w*.08,h*.2,w*.84,h*.6);
 c.fillStyle='#e5e0c7';c.shadowColor='#e9e1ba';c.shadowBlur=unit*.025;c.beginPath();c.arc(w*.89,h*.085,unit*.016,0,Math.PI*2);c.fill();c.shadowBlur=0;
 c.fillStyle='#13243b';c.beginPath();c.moveTo(0,h*.77);for(let i=0;i<=8;i++)c.lineTo(w*i/8,h*(.74+Math.sin(i*2.17)*.018));c.lineTo(w,h*.79);c.lineTo(0,h*.79);c.closePath();c.fill();
 const pairs=final?data.final:event?(decided?event.after:event.before):[];
 for(const [a,b]of pairs)line(c,xl+r,ys[a],xr-r,ys[b],final?'#e6d49c':p.accent,unit*.0018,1,.78);
 if(event){const color=decided&&event.outcome==='reject'?p.danger:'#f2b68a';line(c,xl+r,ys[event.left],xr-r,ys[event.right],color,unit*.0032,q,decided&&event.outcome==='reject'?.5:1);
  if(decided&&event.outcome==='replace')line(c,xl+r,ys[event.previous],xr-r,ys[event.right],p.danger,unit*.0025,1,Math.max(.1,1-(q-.94)/.06));
 }
 c.textAlign='center';c.textBaseline='middle';c.font=`400 ${unit*.031}px VibeSerif,serif`;c.fillStyle=p.text;
 c.fillText('提议方',xl,h*.305);c.fillText('接收方',xr,h*.305);
 for(let i=0;i<n;i++)for(const side of ['left','right']){
  const x=side==='left'?xl:xr,label=side==='left'?leftLabel(i):rightLabel(i),colors=side==='left'?rightColors:leftColors,labels=side==='left'?rightLabel:leftLabel,active=event&&(side==='left'?i===event.left:i===event.right);
  if(active){c.strokeStyle=decided&&event.outcome==='reject'?p.danger:p.accent;c.lineWidth=unit*.0017;c.beginPath();c.arc(x,ys[i],r*1.28,0,Math.PI*2);c.stroke();}
  avatar(c,x,ys[i],r,(side==='left'?leftColors:rightColors)[i],label);
  const prefs=model[side][i],gap=unit*(portrait?.043:.039),prefCenter=portrait?x:w*(side==='left'?.115:.885),px=prefCenter-(n-1)*gap/2,py=portrait?ys[i]+r*1.95:ys[i];
  for(let k=0;k<n;k++){c.fillStyle=colors[prefs[k]];c.beginPath();c.arc(px+k*gap,py,gap*.41,0,Math.PI*2);c.fill();c.font=`600 ${gap*.7}px VibeSerif,serif`;c.fillStyle='#102032';c.fillText(labels(prefs[k]),px+k*gap,py+gap*.025);}
 }
 c.fillStyle=p.accent;c.font=`400 ${unit*.034}px VibeSerif,serif`;
 c.fillText(final?`${data.events.length}次提议 · ${n}对确定`:event?`第${step}/${data.events.length}次提议 · ${leftLabel(event.left)} → ${rightLabel(event.right)}`:'偏好从左到右，依次降低',w*.5,h*.25);
 c.fillStyle=p.text;c.font=`400 ${unit*.033}px VibeSerif,serif`;
 let status='每人只保留一个暂定对象';
 if(final)status=`互相更偏好的未配对组合：${data.blocking_pairs.length}`;
 else if(event)status=!decided?`${leftLabel(event.left)} 向 ${rightLabel(event.right)} 提议`:event.outcome==='reject'?`${rightLabel(event.right)} 保留 ${leftLabel(event.previous)}，拒绝 ${leftLabel(event.left)}`:event.outcome==='replace'?`${rightLabel(event.right)} 改留 ${leftLabel(event.left)}，释放 ${leftLabel(event.previous)}`:`${rightLabel(event.right)} 暂留 ${leftLabel(event.left)}`;
 c.fillText(status,w*.5,h*.747);c.restore();
}
