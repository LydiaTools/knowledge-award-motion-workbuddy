import * as THREE from './vendor/three.module.js';
import {handGeometry} from './hand-geometry.js';

// All geometry is authored here. No network assets, animation loops or wall clocks.
const states=new WeakMap();
const random=(i,seed)=>{let x=(i+1)^seed;x=Math.imul(x^(x>>>16),0x45d9f3b);x=Math.imul(x^(x>>>16),0x45d9f3b);return((x^(x>>>16))>>>0)/4294967296};
const pointVertex=`attribute float strength;varying float vStrength;uniform float size;void main(){vStrength=strength;vec4 mv=modelViewMatrix*vec4(position,1.0);gl_Position=projectionMatrix*mv;gl_PointSize=clamp(size*strength/(-mv.z),1.0,11.0);}`;
const pointFragment=`uniform vec3 color;uniform float opacity;varying float vStrength;void main(){float d=length(gl_PointCoord-.5)*2.0;float a=exp(-d*d*4.0)*(1.0-smoothstep(.65,1.0,d));gl_FragColor=vec4(color,a*opacity*vStrength);}`;
function glowPoints(n,color,seed,size=30){
  const positions=new Float32Array(n*3),strengths=Float32Array.from({length:n},(_,i)=>.3+random(i,seed)*.8);
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.setAttribute('strength',new THREE.BufferAttribute(strengths,1));
  const material=new THREE.ShaderMaterial({uniforms:{color:{value:new THREE.Color(color)},opacity:{value:.8},size:{value:size}},vertexShader:pointVertex,fragmentShader:pointFragment,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending});
  const object=new THREE.Points(geometry,material);object.frustumCulled=false;return{object,positions,geometry,material};
}
function glowDisc(color,radius=1){
  const material=new THREE.ShaderMaterial({uniforms:{color:{value:new THREE.Color(color)},opacity:{value:.6}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'varying vec2 vUv;uniform vec3 color;uniform float opacity;void main(){float r=length(vUv-.5)*2.0;gl_FragColor=vec4(color,exp(-r*r*5.0)*(1.0-smoothstep(.65,1.0,r))*opacity);}',transparent:true,depthWrite:false,blending:THREE.AdditiveBlending});
  return new THREE.Mesh(new THREE.PlaneGeometry(radius*2,radius*2),material);
}
function line(points,color,opacity=.5){return new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color,transparent:true,opacity}));}
function mesh(geometry,material,parent,position=[0,0,0],scale=[1,1,1]){const m=new THREE.Mesh(geometry,material);m.position.set(...position);m.scale.set(...scale);parent.add(m);return m;}
function capsule(a,b,r,material,parent){const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b),length=va.distanceTo(vb);const object=mesh(new THREE.CapsuleGeometry(r,Math.max(0,length-r*2),5,12),material,parent);object.position.copy(va).add(vb).multiplyScalar(.5);object.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),vb.sub(va).normalize());object.castShadow=true;return object;}

function globe(scene,camera,p,seed){
  const root=new THREE.Group();scene.add(root);
  mesh(new THREE.SphereGeometry(1.25,64,40),new THREE.MeshStandardMaterial({color:'#0b283b',roughness:.47,metalness:.62}),root);
  const grid=new THREE.LineBasicMaterial({color:'#648998',transparent:true,opacity:.31});
  for(let k=-4;k<=4;k++){const lat=k*Math.PI/12,rr=1.258*Math.cos(lat),y=1.258*Math.sin(lat);root.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(Array.from({length:129},(_,i)=>new THREE.Vector3(rr*Math.cos(i/128*Math.PI*2),y,rr*Math.sin(i/128*Math.PI*2)))),grid));}
  for(let k=0;k<12;k++){const a=k*Math.PI/12;root.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(Array.from({length:129},(_,i)=>{const b=i/128*Math.PI*2;return new THREE.Vector3(1.258*Math.cos(b)*Math.cos(a),1.258*Math.sin(b),1.258*Math.cos(b)*Math.sin(a))})),grid));}
  const rim=mesh(new THREE.SphereGeometry(1.3,48,32),new THREE.ShaderMaterial({uniforms:{color:{value:new THREE.Color('#438fbc')}},vertexShader:'varying vec3 vNormal;varying vec3 vView;void main(){vec4 p=modelViewMatrix*vec4(position,1.0);vNormal=normalize(normalMatrix*normal);vView=normalize(-p.xyz);gl_Position=projectionMatrix*p;}',fragmentShader:'varying vec3 vNormal;varying vec3 vView;uniform vec3 color;void main(){float rim=pow(1.0-clamp(dot(normalize(vNormal),normalize(vView)),0.0,1.0),3.2);gl_FragColor=vec4(color,rim*.55);}',transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}),root);
  const routes=[];const pins=glowPoints(10,p.accent,seed,58);root.add(pins.object);
  for(let k=0;k<5;k++){
    const a=new THREE.Vector3(Math.cos(k*1.3)*.8,.15+Math.sin(k*2)*.7,.8).normalize().multiplyScalar(1.27);
    const b=new THREE.Vector3(Math.sin(k*1.4)*.9,-.6+random(k,seed),-.7).normalize().multiplyScalar(1.27);
    const axis=new THREE.Vector3().crossVectors(a,b).normalize(),angle=a.angleTo(b);
    const point=u=>a.clone().applyAxisAngle(axis,angle*u).normalize().multiplyScalar(1.27+.52*Math.sin(Math.PI*u));
    root.add(line(Array.from({length:81},(_,i)=>point(i/80)),p.accent,.48));
    const packet=mesh(new THREE.SphereGeometry(.025,12,8),new THREE.MeshBasicMaterial({color:p.accent}),root);const halo=glowDisc(p.accent,.2);packet.add(halo);routes.push({point,packet,halo,k});
    pins.positions.set(a.toArray(),k*6);pins.positions.set(b.toArray(),k*6+3);
  }
  pins.geometry.attributes.position.needsUpdate=true;
  const aura=glowDisc('#215b7c',2.3);aura.position.z=-1.5;scene.add(aura);
  return(t)=>{root.rotation.y=-.48+t*.105;root.rotation.z=-.08;routes.forEach(({point,packet,halo,k})=>{packet.position.copy(point((t*.13+k*.19)%1));halo.quaternion.copy(camera.quaternion).premultiply(root.quaternion.clone().invert());});aura.quaternion.copy(camera.quaternion);rim.rotation.y=0;};
}

function litRoom(scene,camera,p,seed){
  const root=new THREE.Group();scene.add(root);root.position.y=-.6;
  const wallMaterial=new THREE.MeshStandardMaterial({color:'#17212b',roughness:.92,side:THREE.DoubleSide});
  const floor=mesh(new THREE.PlaneGeometry(8,7),new THREE.MeshStandardMaterial({color:'#31343a',roughness:.84}),root,[0,-.75,0]);floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;
  mesh(new THREE.PlaneGeometry(8,4.5),wallMaterial,root,[0,1.45,-2.3]);
  const side=mesh(new THREE.PlaneGeometry(7,4.5),wallMaterial,root,[-3,1.45,0]);side.rotation.y=Math.PI/2;
  const frameMaterial=new THREE.MeshStandardMaterial({color:'#15191d',roughness:.7});
  const windowGroup=new THREE.Group();windowGroup.position.set(-2,1.3,-1.4);windowGroup.rotation.y=.45;root.add(windowGroup);
  const glass=mesh(new THREE.PlaneGeometry(1.8,1.7),new THREE.MeshBasicMaterial({color:'#efd9aa',transparent:true,opacity:.8,side:THREE.DoubleSide}),windowGroup);
  for(const x of [-.95,0,.95]){const bar=mesh(new THREE.BoxGeometry(.075,1.9,.15),frameMaterial,windowGroup,[x,0,.05]);bar.castShadow=true;}
  for(const y of [-.9,0,.9]){const bar=mesh(new THREE.BoxGeometry(1.98,.07,.15),frameMaterial,windowGroup,[0,y,.05]);bar.castShadow=true;}
  // Real shadow-producing light. The transparent beam is only its atmospheric component.
  const sun=new THREE.SpotLight('#ffe0a1',95,18,.39,.28,1);sun.position.set(-3.3,3.2,-3.9);sun.target.position.set(1.5,-.74,1.3);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.bias=-.0004;sun.shadow.normalBias=.02;root.add(sun,sun.target);
  const beamGeometry=new THREE.BufferGeometry();beamGeometry.setAttribute('position',new THREE.Float32BufferAttribute([-2.75,2.2,-1.4,-1.1,2.2,-1.4,3,-.72,2.2,-2.75,2.2,-1.4,3,-.72,2.2,-.6,-.72,2.2],3));
  const beam=new THREE.Mesh(beamGeometry,new THREE.MeshBasicMaterial({color:'#ebcb88',transparent:true,opacity:.055,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));root.add(beam);
  const dust=glowPoints(950,'#f6dba6',seed,24);root.add(dust.object);
  const ball=mesh(new THREE.SphereGeometry(.35,36,24),new THREE.MeshStandardMaterial({color:'#a78855',roughness:.45,metalness:.4}),root,[.45,-.4,.5]);ball.castShadow=true;
  camera.position.set(5,3.4,7.5);if(camera.aspect<1)camera.position.multiplyScalar(1/camera.aspect);camera.lookAt(-.1,.1,0);
  return t=>{
    for(let i=0;i<950;i++){const x=random(i*4,seed),y=random(i*4+1,seed),z=random(i*4+2,seed);dust.positions.set([-2.7+x*5+Math.sin(t*.18+i)*.04,-.65+((y*2.8+t*.024)%2.8),-1.5+z*3.7],i*3);}
    dust.geometry.attributes.position.needsUpdate=true;glass.material.opacity=.75+Math.sin(t*.13)*.05;
  };
}

function cuppedHand(scene,camera,p,seed){
  const root=new THREE.Group();scene.add(root);root.rotation.y=-.25;
  const gold=new THREE.MeshStandardMaterial({color:'#b78c4a',roughness:.36,metalness:.68});
  const hand=mesh(handGeometry(),gold,root);hand.castShadow=true;
  const core=mesh(new THREE.SphereGeometry(.09,24,16),new THREE.MeshBasicMaterial({color:'#fff4c9'}),root,[0,.47,-.05]);
  const coreLight=new THREE.PointLight('#f7c770',12,6,2);coreLight.position.copy(core.position);root.add(coreLight);
  const aura=glowDisc('#f4bf5b',.72);aura.position.copy(core.position);root.add(aura);
  const dust=glowPoints(1400,'#f6cc7d',seed,40);root.add(dust.object);
  camera.position.set(.2,3.8,6.7);if(camera.aspect<1)camera.position.multiplyScalar(1/camera.aspect);camera.lookAt(0,-.08,0);
  return (t,u)=>{
    root.rotation.y=-.25+Math.sin(t*.16)*.12;const pulse=1+Math.sin(t*1.1)*.08;core.scale.setScalar(pulse);coreLight.intensity=12*pulse;aura.quaternion.copy(camera.quaternion).premultiply(root.quaternion.clone().invert());
    const release=Math.pow(Math.max(0,Math.min(1,(u-.65)/.35)),2);
    for(let i=0;i<1400;i++){const q=random(i*4,seed),a=random(i*4+1,seed)*Math.PI*2+t*(.12+q*.12),z=random(i*4+2,seed),r=(.11+q*.7)*(1+release*2.4);dust.positions.set([Math.cos(a)*r,.17+z*.95+Math.sin(a*2)*.04+release*(.3+z),Math.sin(a)*r-.05],i*3);}
    dust.geometry.attributes.position.needsUpdate=true;
  };
}
function create(canvas,type,w,h,p,seed){
  const target=canvas.ownerDocument.createElement('canvas');
  const renderer=new THREE.WebGLRenderer({canvas:target,alpha:true,antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(1);renderer.setSize(w,h,false);renderer.setClearColor(0,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.2;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(38,w/h,.1,60);camera.position.set(0,.2,7/Math.min(1,w/h));camera.lookAt(0,0,0);
  scene.add(new THREE.HemisphereLight('#b9d4ec','#3b2919',1.5));
  const key=new THREE.DirectionalLight('#ffe4b0',3.1);key.position.set(-3,4,5);scene.add(key);
  const rim=new THREE.DirectionalLight('#75b3e6',3);rim.position.set(3,2,-3);scene.add(rim);
  const update=({'globe-routes':globe,'lit-room-3d':litRoom,'cupped-hand-3d':cuppedHand}[type])(scene,camera,p,seed);
  return{key:[type,w,h,seed,p.accent].join(':'),render(t,u){update(t,u);renderer.render(scene,camera);return target},dispose(){const geometries=new Set(),materials=new Set();scene.traverse(o=>{if(o.geometry)geometries.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])if(m)materials.add(m);if(o.isLight&&o.shadow)o.shadow.dispose();});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());renderer.dispose();renderer.forceContextLoss();}};
}
export function renderThree(c,s,w,h,t,u,p,seed){const key=[s.type,w,h,seed,p.accent].join(':');let state=states.get(c.canvas);if(state?.key!==key){state?.dispose();state=create(c.canvas,s.type,w,h,p,seed);states.set(c.canvas,state);}c.drawImage(state.render(t,u),0,0,w,h);const fade=c.createLinearGradient(0,0,0,h);fade.addColorStop(0,p.background);fade.addColorStop(.24,'#00000000');fade.addColorStop(.69,'#00000000');fade.addColorStop(.83,p.background);fade.addColorStop(1,p.background);c.fillStyle=fade;c.fillRect(0,0,w,h);}
