import * as THREE from './vendor/three.module.js';

// Smooth union of an ellipsoid and original capsule bones, extracted with marching tetrahedra.
// The grid and all surface vertices are independent of render time.
export function handGeometry(){
  const bones=[];
  for(let f=0;f<4;f++){
    const x=(f-1.5)*.43,spread=(f-1.5)*.07,shorten=f===0?.16:f===3?.23:0,r=f===3?.145:.16;
    const joints=[[x,-.5,-.35],[x+spread,-.32,-.91+shorten],[x+spread*1.4,.01,-1.22+shorten],[x+spread*1.3,.19,-1.12+shorten]];
    for(let k=0;k<3;k++)bones.push({a:joints[k],b:joints[k+1],r:r*(1-k*.12)});
  }
  const thumb=[[-.79,-.49,.45],[-1.13,-.24,.15],[-1.08,.08,-.18],[-.85,.18,-.29]];
  for(let k=0;k<3;k++)bones.push({a:thumb[k],b:thumb[k+1],r:.19-k*.025});
  bones.push({a:[0,-.59,.55],b:[0,-.82,1.45],r:.46});
  for(const b of bones){b.v=b.b.map((x,i)=>x-b.a[i]);b.l=b.v.reduce((s,x)=>s+x*x,0);}
  const smooth=(a,b,k=.14)=>{const h=Math.max(0,Math.min(1,.5+.5*(b-a)/k));return b+(a-b)*h-k*h*(1-h)};
  function field(x,y,z){
    const py=y+.55,r=[1.02,.24,.85],q=[x,py,z-.03];let k0=0,k1=0;
    for(let j=0;j<3;j++){k0+=(q[j]/r[j])**2;k1+=(q[j]/r[j]**2)**2;}
    k0=Math.sqrt(k0);let value=k0*(k0-1)/Math.max(.00001,Math.sqrt(k1));
    for(const b of bones){const v=[x-b.a[0],y-b.a[1],z-b.a[2]],h=Math.max(0,Math.min(1,v.reduce((s,a,j)=>s+a*b.v[j],0)/b.l));const d=Math.hypot(v[0]-h*b.v[0],v[1]-h*b.v[1],v[2]-h*b.v[2])-b.r;value=smooth(value,d);}
    return value;
  }
  function normal(p){const e=.001;return new THREE.Vector3(field(p[0]+e,p[1],p[2])-field(p[0]-e,p[1],p[2]),field(p[0],p[1]+e,p[2])-field(p[0],p[1]-e,p[2]),field(p[0],p[1],p[2]+e)-field(p[0],p[1],p[2]-e)).normalize();}
  const nx=58,ny=38,nz=72,min=[-1.5,-1.4,-1.6],max=[1.5,.6,2.05];
  const values=new Float32Array(nx*ny*nz),pos=new Float32Array(nx*ny*nz*3),id=(x,y,z)=>x+nx*(y+ny*z);
  for(let z=0;z<nz;z++)for(let y=0;y<ny;y++)for(let x=0;x<nx;x++){const i=id(x,y,z),p=[min[0]+x/(nx-1)*(max[0]-min[0]),min[1]+y/(ny-1)*(max[1]-min[1]),min[2]+z/(nz-1)*(max[2]-min[2])];pos.set(p,i*3);values[i]=field(...p);}
  const tetra=[[0,5,1,6],[0,1,2,6],[0,2,3,6],[0,3,7,6],[0,7,4,6],[0,4,5,6]],edges=[[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]],vertices=[],normals=[];
  for(let z=0;z<nz-1;z++)for(let y=0;y<ny-1;y++)for(let x=0;x<nx-1;x++){
    const cube=[id(x,y,z),id(x+1,y,z),id(x+1,y+1,z),id(x,y+1,z),id(x,y,z+1),id(x+1,y,z+1),id(x+1,y+1,z+1),id(x,y+1,z+1)];
    if(cube.every(i=>values[i]>=0)||cube.every(i=>values[i]<0))continue;
    for(const t of tetra){const ids=t.map(i=>cube[i]),points=[];
      for(const [a,b]of edges){const ia=ids[a],ib=ids[b],va=values[ia],vb=values[ib];if((va<0)===(vb<0))continue;const u=va/(va-vb);points.push([0,1,2].map(k=>pos[ia*3+k]+u*(pos[ib*3+k]-pos[ia*3+k])));}
      if(points.length<3)continue;
      const center=new THREE.Vector3(...points.reduce((s,p)=>s.map((v,j)=>v+p[j]/points.length),[0,0,0])),n=normal(center.toArray()),axis=new THREE.Vector3(...points[0]).sub(center).normalize(),other=new THREE.Vector3().crossVectors(n,axis).normalize();
      points.sort((a,b)=>{const aa=new THREE.Vector3(...a).sub(center),bb=new THREE.Vector3(...b).sub(center);return Math.atan2(aa.dot(other),aa.dot(axis))-Math.atan2(bb.dot(other),bb.dot(axis));});
      for(let j=1;j<points.length-1;j++)for(const p of [points[0],points[j],points[j+1]]){vertices.push(...p);normals.push(...normal(p).toArray());}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));return geometry;
}
