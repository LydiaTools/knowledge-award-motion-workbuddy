import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const opts={};
for(let i=2;i<process.argv.length;i+=2){if(!process.argv[i]?.startsWith('--')||!process.argv[i+1])throw Error('参数必须为 --名称 值');opts[process.argv[i].slice(2)]=process.argv[i+1];}
const p=Number(opts.probability),n=Number(opts.trials),groups=Number(opts.groups??1000),seed=Number(opts.seed??42);
if(!Number.isFinite(p)||p<=0||p>=1||!Number.isInteger(n)||n<1||n>200||!Number.isInteger(groups)||groups<16||groups>2500||!Number.isInteger(seed)||seed<0||seed>2147483647||!opts.out)throw Error('需要 0<p<1、1–200 次、16–2500 组、非负整数种子和新输出目录');
const output=path.resolve(opts.out);
try{await fs.access(output);throw Error('输出目录已存在，拒绝覆盖');}catch(e){if(e.code!=='ENOENT')throw e;}
await fs.cp(path.join(root,'assets','template'),output,{recursive:true,errorOnExist:true,force:false});
const spec=JSON.parse(await fs.readFile(path.join(output,'job.json'),'utf8'));
const pct=x=>Number((x*100).toFixed(4)).toString()+'%';
const result=(100*(1-(1-p)**n)).toFixed(1)+'%';
spec.job_id=`probability-${n}-${seed}`;spec.seed=seed;
spec.backend_only={model:'independent-trials',probability:p,trials:n,groups,assumptions:['independent','constant_probability']};
spec.scenes[0].title=`单次成功${pct(p)}，试${n}次呢？`;
spec.scenes[0].parameters.word=result;
spec.scenes[1].title=`让${groups}组尝试，同时开始`;
spec.scenes[1].body=`每组最多${n}次，亮点表示至少成功过一次。`;
spec.scenes[1].parameters={count:groups,trials:n,probability:p};
spec.scenes[2].title=`先看${n}次都失败的概率`;
spec.scenes[2].body=`每次失败率${pct(1-p)}，将${n}个失败概率相乘。`;
spec.scenes[2].parameters={trials:n,probability:p};
spec.scenes[3].body=`用1减去全部失败的概率，结果约为${result}。`;
spec.scenes[3].parameters={trials:n,probability:p};
spec.scenes[4].body=`各次独立，且每次成功率恒为${pct(p)}。`;
const htmlPath=path.join(output,'index.html');let html=await fs.readFile(htmlPath,'utf8');
const re=/const spec=\{.*?\};const canvas=/s;
if(!re.test(html))throw Error('模板中未找到可替换参数');
html=html.replace(re,`const spec=${JSON.stringify(spec)};const canvas=`);
await fs.writeFile(htmlPath,html,'utf8');
await fs.writeFile(path.join(output,'job.json'),JSON.stringify(spec,null,2)+'\n','utf8');
console.log(JSON.stringify({project:output,probability:p,trials:n,groups,theoretical:1-(1-p)**n},null,2));
