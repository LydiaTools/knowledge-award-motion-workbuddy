import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const opts={};for(let i=2;i<process.argv.length;i+=2){if(!process.argv[i]?.startsWith('--')||!process.argv[i+1])throw Error('参数必须为 --名称 值');opts[process.argv[i].slice(2)]=process.argv[i+1];}
if(!opts.project||!opts.out)throw Error('需要 --project 与 --out');
const project=path.resolve(opts.project),out=path.resolve(opts.out),cli=opts.cli?path.resolve(opts.cli):path.join(root,'node_modules','hyperframes','bin','hyperframes.mjs');
await fs.access(path.join(project,'index.html'));await fs.access(path.join(project,'assets','score.wav'));await fs.access(cli);
try{await fs.access(out);throw Error('输出文件已存在，拒绝覆盖');}catch(e){if(e.code!=='ENOENT')throw e;}
const silent=out+'.picture.mp4';try{await fs.access(silent);throw Error('临时输出已存在，拒绝覆盖');}catch(e){if(e.code!=='ENOENT')throw e;}
function run(command,args){const r=spawnSync(command,args,{stdio:'inherit',windowsHide:true});if(r.error)throw r.error;if(r.status!==0)throw Error(`执行失败: ${command} (${r.status})`);}
run(process.execPath,[cli,'lint',project]);
run(process.execPath,[cli,'render',project,'-o',silent,'--fps','30','--workers','2','--quality','looks']);
run('ffmpeg',['-v','error','-n','-i',silent,'-i',path.join(project,'assets','score.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t','40','-movflags','+faststart',out]);
console.log(`生成完成: ${out}`);
